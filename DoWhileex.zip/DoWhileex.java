package gillpack;

public class DoWhileex {
	public static void main(String[] args) {  
	    int i=10;  
	    do{  
	        System.out.println(i); // the loop will execute once even when i=10 and condition is i<10  
	    i++;  
	    }while(i<15);  
	}  


}
