package gillpack;

public class assignops {
	public static void main(String[] args) {
		int x = 5;
		x += 5;
		System.out.println(x);
		
		int y = 5;
		y -= 4;
		System.out.println(y);
		
		int z = 6;
		z*=3;
		System.out.println(z);
		
		int i =8;
		i/=2;
		System.out.println(i);
		
		int j =8;
		j%=2;
		System.out.println(j);
	}
}
